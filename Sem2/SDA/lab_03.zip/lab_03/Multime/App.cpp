
#include "TestExtins.h"
#include "TestScurt.h"
#include <iostream>
using namespace std;

int main() {

	testAll();
	testAnterior();
	testAllExtins();

	cout << "That's all!" << endl;

}
