#pragma once
void testAnterior();
void testAll();